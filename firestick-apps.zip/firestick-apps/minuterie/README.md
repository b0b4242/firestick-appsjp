# Minuterie pour Fire Stick

Réglez une durée, choisissez une application et ce qui doit se passer à la fin.

## Télécommande

- **Haut / Bas** : changer de ligne
- **Gauche / Droite** : changer la valeur (OK fait la même chose, vers la droite)
- **OK sur « Démarrer »** : lance la minuterie
- Pendant le compte à rebours : **OK** annule, **Retour** quitte l'écran (la minuterie continue)

## Actions à la fin

- Fermer l'application (retour à l'accueil + arrêt de l'app)
- Ouvrir l'application
- Lancer FireSaver (`com.jp.firesaver`)
- Baisser la luminosité au minimum (app Luminosité, `com.jp.luminosite`)
- Mettre la lecture en pause
- Jouer un son d'alerte

« Lancer l'app au démarrage » ouvre l'application choisie en même temps que la minuterie.
Les derniers réglages sont gardés d'une fois à l'autre.

## Installation

1. Installer l'APK (Downloader ou `adb install`).
2. Une seule fois, pour que l'app puisse lancer des apps en arrière-plan :

   `adb shell appops set com.jp.minuterie SYSTEM_ALERT_WINDOW allow`

## Limites

- Une minuterie en cours est perdue si le Fire Stick redémarre.
- « Mettre en pause » dépend de l'app de lecture : certaines ignorent la commande.
