package com.jp.hub;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Liste des raccourcis. OK = lancer, Menu = modifier, Play/Pause = annuler la minuterie en cours. */
public class ShortcutsActivity extends Activity {

    private List<Shortcut> list = new ArrayList<>();
    private final List<View> rows = new ArrayList<>();
    private LinearLayout col;
    private ScrollView sv;
    private TextView timerInfo;
    private int sel = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackground(Ui.background());
        root.setPadding(0, Ui.dp(this, 28), 0, Ui.dp(this, 20));

        root.addView(Ui.text(this, "Raccourcis", 28, Color.WHITE, true));
        timerInfo = Ui.text(this, "", 14, Ui.ACCENT, false);
        timerInfo.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        root.addView(timerInfo);

        sv = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView hint = Ui.text(this, "OK : lancer     Menu : modifier     Play/Pause : annuler la minuterie", 13, 0x88FFFFFF, false);
        hint.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(hint);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        list = Shortcut.load(this);
        sel = Math.min(sel, list.size());
        build();
        updateTimerInfo();
    }

    private void build() {
        col.removeAllViews();
        rows.clear();
        for (int i = 0; i <= list.size(); i++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.VERTICAL);
            r.setPadding(Ui.dp(this, 26), Ui.dp(this, 12), Ui.dp(this, 26), Ui.dp(this, 12));
            boolean add = i == list.size();
            TextView t = Ui.text(this, add ? "+  Nouveau raccourci" : list.get(i).name, 20, Color.WHITE, false);
            t.setGravity(Gravity.START);
            r.addView(t);
            if (!add) {
                TextView s = Ui.text(this, list.get(i).summary(this), 13, 0x99FFFFFF, false);
                s.setGravity(Gravity.START);
                r.addView(s);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 780), LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(this, 8);
            col.addView(r, lp);
            rows.add(r);
        }
        render();
    }

    private void render() {
        for (int i = 0; i < rows.size(); i++) rows.get(i).setBackground(Ui.box(this, i == sel));
        final View v = rows.get(sel);
        sv.post(new Runnable() {
            @Override public void run() {
                sv.smoothScrollTo(0, Math.max(0, v.getTop() - Ui.dp(ShortcutsActivity.this, 90)));
            }
        });
    }

    private void updateTimerInfo() {
        long end = getSharedPreferences(Actions.PREFS, Context.MODE_PRIVATE).getLong(Actions.K_TIMER_END, 0);
        if (end > System.currentTimeMillis()) {
            timerInfo.setText("Minuterie en cours · fin à "
                    + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(end)));
        } else {
            timerInfo.setText("");
        }
    }

    private void edit(int index) {
        Intent i = new Intent(this, EditActivity.class);
        i.putExtra("index", index);
        startActivity(i);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        int n = rows.size();
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                sel = (sel + n - 1) % n;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                sel = (sel + 1) % n;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (e.getRepeatCount() == 0) {
                    if (sel == list.size()) {
                        edit(-1);
                    } else {
                        Toast.makeText(this, list.get(sel).run(this), Toast.LENGTH_LONG).show();
                        updateTimerInfo();
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MENU:
                if (sel < list.size()) edit(sel);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                Actions.cancelTimer(this);
                updateTimerInfo();
                Toast.makeText(this, "Minuterie annulée", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }
}
