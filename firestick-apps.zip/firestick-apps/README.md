# Apps Fire Stick

Quatre apps compilées automatiquement par GitHub Actions :

| Dossier | App | APK |
|---|---|---|
| `firesaver` | FireSaver 2.0 (économiseur d'écran) | `firesaver.apk` |
| `luminosite` | Luminosité (+ télécommande téléphone) | `luminosite.apk`, `luminosite-remote.apk` |
| `minuterie` | Minuterie | `minuterie.apk` |
| `hub` | Hub (tout au même endroit) | `hub.apk` |

Les APK sont publiés dans la version « Dernière version » (tag `latest`) :
`https://github.com/TON-NOM/TON-DEPOT/releases/download/latest/NOM.apk`
