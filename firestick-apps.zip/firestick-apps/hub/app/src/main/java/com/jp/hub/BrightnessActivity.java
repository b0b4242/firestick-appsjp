package com.jp.hub;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Réglage de la luminosité, en pilotant l'app Luminosité.
 * Gauche/Droite = 1 % (maintenu : 5 %), Haut/Bas = 10 %, OK = mode nuit, Menu = ouvrir l'app Luminosité.
 */
public class BrightnessActivity extends Activity {

    private static final int BAR_DP = 640;

    private int brightness = 100, night = 0;
    private TextView pct, nightTv, info;
    private View fill;

    private final BroadcastReceiver status = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            handle(getResultData());
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.background());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        col.addView(Ui.text(this, "Luminosité", 26, 0xCCFFFFFF, true));
        pct = Ui.text(this, "", 84, Ui.ACCENT, true);
        col.addView(pct);

        FrameLayout track = new FrameLayout(this);
        track.setBackground(roundedBar(0x26FFFFFF));
        fill = new View(this);
        fill.setBackground(roundedBar(Ui.ACCENT));
        track.addView(fill, new FrameLayout.LayoutParams(0, Ui.dp(this, 18)));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(Ui.dp(this, BAR_DP), Ui.dp(this, 18));
        tlp.topMargin = Ui.dp(this, 14);
        col.addView(track, tlp);

        nightTv = Ui.text(this, "", 20, Color.WHITE, false);
        nightTv.setPadding(0, Ui.dp(this, 30), 0, 0);
        col.addView(nightTv);

        info = Ui.text(this, "", 14, 0xAAFFFFFF, false);
        info.setPadding(0, Ui.dp(this, 14), 0, 0);
        col.addView(info);

        TextView hint = Ui.text(this,
                "Gauche / Droite : 1 %     Haut / Bas : 10 %     OK : mode nuit     Menu : app Luminosité",
                13, 0x88FFFFFF, false);
        hint.setPadding(0, Ui.dp(this, 36), 0, 0);
        col.addView(hint);

        root.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);
        render();
    }

    private android.graphics.drawable.GradientDrawable roundedBar(int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(this, 9));
        return g;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Actions.lumiRead(this, null, 0, status);   // lit l'état actuel
    }

    private void handle(String d) {
        if (d == null) {
            info.setText("L'app Luminosité n'est pas installée");
            return;
        }
        Matcher m = Pattern.compile("brightness=(\\d+)").matcher(d);
        if (m.find()) brightness = Integer.parseInt(m.group(1));
        m = Pattern.compile("night=(\\d)").matcher(d);
        if (m.find()) night = Integer.parseInt(m.group(1));
        info.setText(d.startsWith("permission")
                ? "Autorisation manquante : adb shell appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow"
                : "");
        render();
    }

    private void render() {
        pct.setText(brightness + " %");
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) fill.getLayoutParams();
        lp.width = Ui.dp(this, BAR_DP) * brightness / 100;
        fill.setLayoutParams(lp);
        nightTv.setText(night == 1 ? "Mode nuit : activé" : "Mode nuit : désactivé");
        nightTv.setTextColor(night == 1 ? Ui.ACCENT : 0xAAFFFFFF);
    }

    private void setBrightness(int v) {
        brightness = Math.max(5, Math.min(100, v));
        Actions.lumi(this, "brightness", brightness);
        render();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                setBrightness(brightness - (e.getRepeatCount() > 0 ? 5 : 1));
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                setBrightness(brightness + (e.getRepeatCount() > 0 ? 5 : 1));
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                setBrightness(brightness + 10);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                setBrightness(brightness - 10);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (e.getRepeatCount() == 0) Actions.lumiRead(this, "night", 2, status);
                return true;
            case KeyEvent.KEYCODE_MENU:
                if (!Actions.launch(this, Actions.LUMI)) {
                    Toast.makeText(this, "Luminosité n'est pas installée", Toast.LENGTH_LONG).show();
                }
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }
}
