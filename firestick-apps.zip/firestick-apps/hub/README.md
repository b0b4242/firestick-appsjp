# Hub pour Fire Stick

Un écran d'accueil qui réunit FireSaver, Luminosité, Minuterie et des raccourcis.

- **FireSaver / Minuterie** : ouvre l'app (il faut qu'elle soit installée).
- **Luminosité** : règle la luminosité (Gauche/Droite = 1 %, Haut/Bas = 10 %), OK = mode nuit, Menu = ouvre l'app Luminosité.
- **Raccourcis** : un clic applique plusieurs réglages à la fois (luminosité, mode nuit, lancer une app, minuterie avec action de fin).
  OK = lancer, Menu = modifier, Play/Pause = annuler la minuterie en cours.

## Installation

1. Installe l'APK (lien « latest » du dépôt GitHub).
2. Une seule fois : `adb shell appops set com.jp.hub SYSTEM_ALERT_WINDOW allow`
3. Luminosité doit avoir sa propre autorisation (`adb shell appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow`).
