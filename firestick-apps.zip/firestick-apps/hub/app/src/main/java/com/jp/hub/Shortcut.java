package com.jp.hub;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Un raccourci = une suite de réglages appliqués d'un seul clic. */
final class Shortcut {
    static final String K = "shortcuts";

    String name = "Nouveau raccourci";
    int brightness = -1;           // -1 = ne pas changer, sinon 5..100
    int night = -1;                // -1 = ne pas changer, 0 = éteint, 1 = allumé
    String pkg = null;             // app à lancer (ou null)
    int timerMin = 0;              // 0 = pas de minuterie
    int endAction = Actions.CLOSE; // ce qui se passe à la fin de la minuterie

    static String durText(int min) {
        if (min < 60) return min + " min";
        int h = min / 60, m = min % 60;
        return m == 0 ? h + " h" : h + " h " + m + " min";
    }

    String summary(Context c) {
        List<String> p = new ArrayList<>();
        if (brightness >= 0) p.add("Luminosité " + brightness + " %");
        if (night == 1) p.add("Mode nuit activé");
        if (night == 0) p.add("Mode nuit désactivé");
        if (pkg != null) p.add("Lance " + Actions.labelOf(c, pkg));
        if (timerMin > 0) p.add("Minuterie " + durText(timerMin) + " → " + Actions.END_NAMES[endAction]);
        if (p.isEmpty()) return "Aucune action";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < p.size(); i++) sb.append(i > 0 ? "  ·  " : "").append(p.get(i));
        return sb.toString();
    }

    /** Applique le raccourci. Rend un court message à afficher. */
    String run(Context c) {
        if (brightness >= 0) Actions.lumi(c, "brightness", brightness);
        if (night >= 0) Actions.lumi(c, "night", night);
        String msg = name + " appliqué";
        if (timerMin > 0) {
            Actions.schedule(c, System.currentTimeMillis() + timerMin * 60000L, endAction, pkg);
            msg += " · minuterie " + durText(timerMin);
        }
        if (pkg != null && !Actions.launch(c, pkg)) msg = Actions.labelOf(c, pkg) + " est introuvable";
        return msg;
    }

    // ---------- sauvegarde ----------

    private JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", name).put("brightness", brightness).put("night", night)
                .put("timerMin", timerMin).put("endAction", endAction);
        if (pkg != null) o.put("pkg", pkg);
        return o;
    }

    private static Shortcut fromJson(JSONObject o) {
        Shortcut s = new Shortcut();
        s.name = o.optString("name", s.name);
        s.brightness = o.optInt("brightness", -1);
        s.night = o.optInt("night", -1);
        s.pkg = o.has("pkg") ? o.optString("pkg") : null;
        s.timerMin = o.optInt("timerMin", 0);
        s.endAction = Math.max(0, Math.min(Actions.END_NAMES.length - 1, o.optInt("endAction", Actions.CLOSE)));
        return s;
    }

    private static Shortcut make(String name, int b, int n, int t, int end) {
        Shortcut s = new Shortcut();
        s.name = name; s.brightness = b; s.night = n; s.timerMin = t; s.endAction = end;
        return s;
    }

    static List<Shortcut> load(Context c) {
        SharedPreferences p = c.getSharedPreferences(Actions.PREFS, Context.MODE_PRIVATE);
        List<Shortcut> out = new ArrayList<>();
        String raw = p.getString(K, null);
        if (raw != null) {
            try {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) out.add(fromJson(a.getJSONObject(i)));
                return out;
            } catch (Exception ignored) {
                out.clear();
            }
        }
        // Premier lancement : trois exemples à modifier
        out.add(make("Mode film", 40, 0, 0, Actions.CLOSE));
        out.add(make("Mode nuit", 20, 1, 30, Actions.PAUSE));
        out.add(make("Plein éclat", 100, 0, 0, Actions.CLOSE));
        save(c, out);
        return out;
    }

    static void save(Context c, List<Shortcut> list) {
        try {
            JSONArray a = new JSONArray();
            for (Shortcut s : list) a.put(s.toJson());
            c.getSharedPreferences(Actions.PREFS, Context.MODE_PRIVATE).edit().putString(K, a.toString()).apply();
        } catch (Exception ignored) { }
    }
}
