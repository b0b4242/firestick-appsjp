package com.jp.minuterie;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minuterie pour Fire Stick.
 * Haut/Bas = changer de ligne, Gauche/Droite = changer la valeur, OK = valider.
 * Pendant le compte à rebours : OK = annuler, Retour = quitter l'écran (la minuterie continue).
 */
public class MainActivity extends Activity {

    static final String PREFS = "minuterie";
    static final String K_END = "end_at";        // moment de fin (ms), 0 = aucune minuterie
    private static final String K_DUR = "dur_idx";
    private static final String K_PKG = "pkg";
    private static final String K_ACT = "action";
    private static final String K_NOW = "launch_now";

    private static final int ACCENT = 0xFFFFB347;
    private static final int[] MINUTES = {1, 2, 5, 10, 15, 20, 30, 45, 60, 90, 120, 150, 180};
    private static final int ROWS = 5;   // durée, app, lancer au départ, action, démarrer

    private static final class AppEntry {
        final String pkg, label;
        AppEntry(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    private SharedPreferences prefs;
    private final List<AppEntry> apps = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private int durIdx, appIdx, action, row;
    private boolean launchNow;

    private final TextView[] rowViews = new TextView[ROWS];
    private LinearLayout form, runView;
    private TextView runTime, runInfo;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        loadApps();

        durIdx = Math.max(0, Math.min(MINUTES.length - 1, prefs.getInt(K_DUR, 6)));
        action = Math.max(0, Math.min(TimerReceiver.ACTION_NAMES.length - 1, prefs.getInt(K_ACT, 0)));
        launchNow = prefs.getBoolean(K_NOW, false);
        String savedPkg = prefs.getString(K_PKG, null);
        for (int i = 0; i < apps.size(); i++) {
            if (apps.get(i).pkg.equals(savedPkg)) appIdx = i;
        }

        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    @Override
    protected void onPause() {
        ui.removeCallbacksAndMessages(null);
        super.onPause();
    }

    // ---------- données ----------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Map<String, String> found = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || found.containsKey(pkg)) continue;
                found.put(pkg, String.valueOf(ri.loadLabel(pm)));
            }
        }
        for (Map.Entry<String, String> e : found.entrySet()) {
            apps.add(new AppEntry(e.getKey(), e.getValue()));
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override public int compare(AppEntry a, AppEntry b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
    }

    private String appLabel() {
        return apps.isEmpty() ? "(aucune app trouvée)" : apps.get(appIdx).label;
    }

    private String appPkg() {
        return apps.isEmpty() ? null : apps.get(appIdx).pkg;
    }

    private static String durText(int min) {
        if (min < 60) return min + " min";
        int h = min / 60, m = min % 60;
        return m == 0 ? h + " h" : h + " h " + m + " min";
    }

    // ---------- interface ----------

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color, boolean light) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(light ? "sans-serif-light" : "sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF181A21, 0xFF0A0B0F, 0xFF000000}));

        // Formulaire
        form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = text("Minuterie", 30, Color.WHITE, true);
        title.setPadding(0, 0, 0, dp(22));
        form.addView(title);
        for (int i = 0; i < ROWS; i++) {
            TextView r = text("", 20, Color.WHITE, false);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(26), dp(12), dp(26), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(640), LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            form.addView(r, lp);
            rowViews[i] = r;
        }
        TextView hint = text("Haut/Bas : ligne   Gauche/Droite : valeur   OK : valider", 13, 0x88FFFFFF, false);
        hint.setPadding(0, dp(14), 0, 0);
        form.addView(hint);
        root.addView(form, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // Compte à rebours
        runView = new LinearLayout(this);
        runView.setOrientation(LinearLayout.VERTICAL);
        runView.setGravity(Gravity.CENTER_HORIZONTAL);
        runTime = text("", 84, ACCENT, true);
        runInfo = text("", 18, 0xCCFFFFFF, true);
        runInfo.setPadding(0, dp(10), 0, dp(26));
        TextView runHint = text("OK : annuler la minuterie   Retour : quitter l'écran (elle continue)", 13, 0x88FFFFFF, false);
        runView.addView(runTime);
        runView.addView(runInfo);
        runView.addView(runHint);
        runView.setVisibility(View.GONE);
        root.addView(runView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        setContentView(root);
        renderRows();
    }

    private void renderRows() {
        String[] labels = {
                "Durée", "Application", "Lancer l'app au démarrage", "À la fin", "▶  Démarrer"
        };
        String[] values = {
                durText(MINUTES[durIdx]), appLabel(), launchNow ? "Oui" : "Non",
                TimerReceiver.ACTION_NAMES[action], ""
        };
        for (int i = 0; i < ROWS; i++) {
            boolean sel = i == row;
            String t = i == ROWS - 1 ? labels[i]
                    : labels[i] + "    " + (sel ? "‹ " : "") + values[i] + (sel ? " ›" : "");
            rowViews[i].setText(t);
            rowViews[i].setTextColor(sel ? Color.WHITE : 0xAAFFFFFF);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(sel ? 0x26FFFFFF : 0x0DFFFFFF);
            if (sel) g.setStroke(dp(2), ACCENT);
            rowViews[i].setBackground(g);
        }
    }

    /** Affiche le formulaire ou le compte à rebours selon l'état enregistré. */
    private void refreshState() {
        ui.removeCallbacksAndMessages(null);
        long end = prefs.getLong(K_END, 0);
        if (end > System.currentTimeMillis()) {
            form.setVisibility(View.GONE);
            runView.setVisibility(View.VISIBLE);
            tick();
        } else {
            if (end != 0) prefs.edit().remove(K_END).apply();
            runView.setVisibility(View.GONE);
            form.setVisibility(View.VISIBLE);
        }
    }

    private void tick() {
        long left = prefs.getLong(K_END, 0) - System.currentTimeMillis();
        if (left <= 0) {
            refreshState();
            return;
        }
        long s = (left + 999) / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        runTime.setText(h > 0 ? String.format("%d:%02d:%02d", h, m, sec) : String.format("%02d:%02d", m, sec));
        runInfo.setText(TimerReceiver.ACTION_NAMES[prefs.getInt(K_ACT, 0)]
                + (prefs.getInt(K_ACT, 0) <= 1 ? " : " + labelOf(prefs.getString(K_PKG, null)) : ""));
        ui.postDelayed(new Runnable() {
            @Override public void run() { tick(); }
        }, 500);
    }

    private String labelOf(String pkg) {
        for (AppEntry a : apps) if (a.pkg.equals(pkg)) return a.label;
        return String.valueOf(pkg);
    }

    // ---------- actions ----------

    private void start() {
        String pkg = appPkg();
        boolean needsApp = action == TimerReceiver.CLOSE || action == TimerReceiver.OPEN;
        if (needsApp && pkg == null) return;

        long end = System.currentTimeMillis() + MINUTES[durIdx] * 60000L;
        prefs.edit()
                .putInt(K_DUR, durIdx).putInt(K_ACT, action).putBoolean(K_NOW, launchNow)
                .putString(K_PKG, pkg).putLong(K_END, end).apply();
        TimerReceiver.schedule(this, end, action, pkg);

        if (launchNow && pkg != null) {
            TimerReceiver.launch(this, pkg);
            finish();
        } else {
            refreshState();
        }
    }

    private void cancelTimer() {
        TimerReceiver.cancel(this);
        prefs.edit().remove(K_END).apply();
        refreshState();
    }

    private void change(int d) {
        switch (row) {
            case 0:
                durIdx = Math.max(0, Math.min(MINUTES.length - 1, durIdx + d));
                break;
            case 1:
                if (!apps.isEmpty()) appIdx = (appIdx + d + apps.size()) % apps.size();
                break;
            case 2:
                launchNow = !launchNow;
                break;
            case 3:
                int n = TimerReceiver.ACTION_NAMES.length;
                action = (action + d + n) % n;
                break;
            default:
                break;
        }
        renderRows();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean running = runView.getVisibility() == View.VISIBLE;
        boolean ok = keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER;

        if (running) {
            if (ok && event.getRepeatCount() == 0) { cancelTimer(); return true; }
            return super.onKeyDown(keyCode, event);
        }

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                row = (row + ROWS - 1) % ROWS;
                renderRows();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                row = (row + 1) % ROWS;
                renderRows();
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                change(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                change(1);
                return true;
            default:
                if (ok && event.getRepeatCount() == 0) {
                    if (row == ROWS - 1) start();
                    else change(1);
                    return true;
                }
                return super.onKeyDown(keyCode, event);
        }
    }
}
