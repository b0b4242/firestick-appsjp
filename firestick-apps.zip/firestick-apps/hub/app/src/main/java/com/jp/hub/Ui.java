package com.jp.hub;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.TextView;

/** Petits utilitaires d'interface partagés par tous les écrans. */
final class Ui {
    static final int ACCENT = 0xFFFFB347;

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable background() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF181A21, 0xFF0A0B0F, 0xFF000000});
    }

    static TextView text(Context c, String s, int sp, int color, boolean light) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(light ? "sans-serif-light" : "sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static GradientDrawable box(Context c, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(c, 14));
        g.setColor(selected ? 0x26FFFFFF : 0x0DFFFFFF);
        if (selected) g.setStroke(dp(c, 2), ACCENT);
        return g;
    }
}
