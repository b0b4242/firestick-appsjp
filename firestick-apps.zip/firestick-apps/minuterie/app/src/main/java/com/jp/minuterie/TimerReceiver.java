package com.jp.minuterie;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;

/** Se réveille à la fin de la minuterie et exécute l'action choisie. */
public class TimerReceiver extends BroadcastReceiver {

    static final String ACTION_FIRE = "com.jp.minuterie.FIRE";
    static final String X_ACTION = "action";
    static final String X_PKG = "pkg";

    // Actions possibles à la fin
    static final int CLOSE = 0, OPEN = 1, FIRESAVER = 2, DIM = 3, PAUSE = 4, SOUND = 5;
    static final String[] ACTION_NAMES = {
            "Fermer l'application", "Ouvrir l'application", "Lancer FireSaver",
            "Baisser la luminosité au minimum", "Mettre la lecture en pause", "Jouer un son d'alerte"
    };

    static PendingIntent pending(Context c, int action, String pkg) {
        Intent i = new Intent(c, TimerReceiver.class);
        i.setAction(ACTION_FIRE);
        i.putExtra(X_ACTION, action);
        i.putExtra(X_PKG, pkg);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, 1, i, flags);
    }

    static void schedule(Context c, long atMillis, int action, String pkg) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, action, pkg);
        if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, atMillis, pi);
        }
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c, 0, null));
    }

    static void launch(Context c, String pkg) {
        if (pkg == null) return;
        Intent i = c.getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    private static void goHome(Context c) {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(h);
    }

    @Override
    public void onReceive(final Context c, Intent i) {
        c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().remove(MainActivity.K_END).apply();

        int action = i.getIntExtra(X_ACTION, CLOSE);
        final String pkg = i.getStringExtra(X_PKG);
        final PendingResult result = goAsync();
        Handler h = new Handler(Looper.getMainLooper());
        long wait = 0;

        try {
            switch (action) {
                case CLOSE:
                    goHome(c);
                    // L'app est maintenant en arrière-plan : on peut la tuer pour de bon.
                    h.postDelayed(new Runnable() {
                        @Override public void run() {
                            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                            if (am != null && pkg != null) am.killBackgroundProcesses(pkg);
                        }
                    }, 1500);
                    wait = 2500;
                    break;
                case OPEN:
                    launch(c, pkg);
                    break;
                case FIRESAVER:
                    Intent f = new Intent();
                    f.setComponent(new ComponentName("com.jp.firesaver", "com.jp.firesaver.MainActivity"));
                    f.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(f);
                    break;
                case DIM:
                    Intent d = new Intent();
                    d.setComponent(new ComponentName("com.jp.luminosite", "com.jp.luminosite.ControlReceiver"));
                    d.putExtra("brightness", 5);
                    c.sendBroadcast(d);
                    break;
                case PAUSE:
                    AudioManager a = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                    a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE));
                    a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE));
                    break;
                case SOUND:
                    Ringtone r = RingtoneManager.getRingtone(c,
                            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                    if (r != null) r.play();
                    wait = 3000;
                    break;
                default:
                    break;
            }
        } catch (Exception ignored) {
            // App introuvable ou lancement refusé : rien à faire de plus.
        }

        h.postDelayed(new Runnable() {
            @Override public void run() { result.finish(); }
        }, wait);
    }
}
