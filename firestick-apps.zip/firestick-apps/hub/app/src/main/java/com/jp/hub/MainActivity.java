package com.jp.hub;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Écran d'accueil du Hub : quatre tuiles. Gauche/Droite = choisir, OK = ouvrir. */
public class MainActivity extends Activity {

    private static final String[] NAMES = {"FireSaver", "Luminosité", "Minuterie", "Raccourcis"};
    private static final int[] LOGOS = {
            R.drawable.tile_firesaver, R.drawable.tile_luminosite,
            R.drawable.tile_minuterie, R.drawable.tile_raccourcis
    };

    private final View[] tiles = new View[4];
    private final TextView[] labels = new TextView[4];
    private int sel = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.background());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = Ui.text(this, "Hub", 34, Color.WHITE, true);
        title.setPadding(0, 0, 0, Ui.dp(this, 36));
        col.addView(title);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView img = new ImageView(this);
            img.setImageResource(LOGOS[i]);
            tile.addView(img, new LinearLayout.LayoutParams(Ui.dp(this, 170), Ui.dp(this, 170)));
            TextView label = Ui.text(this, NAMES[i], 17, Color.WHITE, false);
            label.setPadding(0, Ui.dp(this, 14), 0, 0);
            tile.addView(label);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(Ui.dp(this, 22), 0, Ui.dp(this, 22), 0);
            row.addView(tile, lp);
            tiles[i] = tile;
            labels[i] = label;
        }
        col.addView(row);

        TextView hint = Ui.text(this, "Gauche / Droite : choisir     OK : ouvrir", 13, 0x88FFFFFF, false);
        hint.setPadding(0, Ui.dp(this, 40), 0, 0);
        col.addView(hint);

        root.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);
        render();
    }

    private void render() {
        for (int i = 0; i < 4; i++) {
            boolean s = i == sel;
            tiles[i].setScaleX(s ? 1.14f : 1f);
            tiles[i].setScaleY(s ? 1.14f : 1f);
            tiles[i].setAlpha(s ? 1f : 0.55f);
            labels[i].setTextColor(s ? Ui.ACCENT : 0xAAFFFFFF);
        }
    }

    private void open() {
        switch (sel) {
            case 0:
                if (!Actions.launch(this, Actions.FIRESAVER)) missing("FireSaver");
                break;
            case 1:
                startActivity(new Intent(this, BrightnessActivity.class));
                break;
            case 2:
                if (!Actions.launch(this, Actions.MINUTERIE)) missing("Minuterie");
                break;
            default:
                startActivity(new Intent(this, ShortcutsActivity.class));
                break;
        }
    }

    private void missing(String name) {
        Toast.makeText(this, name + " n'est pas installé", Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                sel = (sel + 3) % 4;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                sel = (sel + 1) % 4;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (e.getRepeatCount() == 0) open();
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }
}
