package com.jp.hub;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Création / modification d'un raccourci.
 * Haut/Bas = ligne, Gauche/Droite = valeur, OK = valider (sur « Nom » : taper le nom). Retour = abandonner.
 */
public class EditActivity extends Activity {

    private static final int[] TIMERS = {0, 5, 10, 15, 30, 45, 60, 90, 120, 180};
    private static final int NAME = 0, BRIGHT = 1, NIGHT = 2, APP = 3, TIMER = 4, END = 5, SAVE = 6, DELETE = 7;

    private List<Shortcut> all;
    private Shortcut s;
    private int index;
    private List<String[]> apps;
    private int appIdx = -1;      // -1 = aucune app
    private int row = 0;
    private boolean confirmDelete = false;
    private TextView[] views;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        all = Shortcut.load(this);
        index = getIntent().getIntExtra("index", -1);
        s = index >= 0 && index < all.size() ? all.get(index) : new Shortcut();
        if (index >= all.size()) index = -1;
        apps = Actions.loadApps(this);
        if (s.pkg != null) {
            for (int i = 0; i < apps.size(); i++) if (apps.get(i)[0].equals(s.pkg)) appIdx = i;
            if (appIdx < 0) s.pkg = null;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackground(Ui.background());

        root.addView(Ui.text(this, index >= 0 ? "Modifier le raccourci" : "Nouveau raccourci", 26, Color.WHITE, true));
        int n = index >= 0 ? 8 : 7;
        views = new TextView[8];
        for (int i = 0; i < n; i++) {
            TextView t = Ui.text(this, "", 19, Color.WHITE, false);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding(Ui.dp(this, 26), Ui.dp(this, 10), Ui.dp(this, 26), Ui.dp(this, 10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 700), LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 7);
            root.addView(t, lp);
            views[i] = t;
        }
        TextView hint = Ui.text(this, "Haut/Bas : ligne   Gauche/Droite : valeur   OK : valider   Retour : abandonner", 13, 0x88FFFFFF, false);
        hint.setPadding(0, Ui.dp(this, 16), 0, 0);
        root.addView(hint);
        setContentView(root);
        render();
    }

    private int rowCount() { return index >= 0 ? 8 : 7; }

    private String value(int r) {
        switch (r) {
            case NAME: return s.name;
            case BRIGHT: return s.brightness < 0 ? "Inchangée" : s.brightness + " %";
            case NIGHT: return s.night < 0 ? "Inchangé" : (s.night == 1 ? "Activé" : "Désactivé");
            case APP: return appIdx < 0 ? "Aucune" : apps.get(appIdx)[1];
            case TIMER: return s.timerMin == 0 ? "Aucune" : Shortcut.durText(s.timerMin);
            default: return Actions.END_NAMES[s.endAction];
        }
    }

    private void render() {
        String[] labels = {"Nom", "Luminosité", "Mode nuit", "Lancer l'app", "Minuterie", "À la fin de la minuterie", "✔  Enregistrer", "✖  Supprimer"};
        for (int i = 0; i < rowCount(); i++) {
            boolean sel = i == row;
            String t;
            if (i == SAVE) t = labels[i];
            else if (i == DELETE) t = confirmDelete ? "✖  Appuyer encore sur OK pour supprimer" : labels[i];
            else t = labels[i] + "    " + (sel && i != NAME ? "‹ " : "") + value(i) + (sel && i != NAME ? " ›" : "");
            views[i].setText(t);
            boolean dim = i == END && s.timerMin == 0;
            views[i].setTextColor(dim ? 0x55FFFFFF : (sel ? Color.WHITE : 0xAAFFFFFF));
            views[i].setBackground(Ui.box(this, sel));
        }
    }

    private void change(int d) {
        switch (row) {
            case BRIGHT: {
                int v = s.brightness < 0 ? 0 : s.brightness;   // 0 = inchangée
                v = Math.max(0, Math.min(100, v + d * 5));
                s.brightness = v < 5 ? -1 : v;
                break;
            }
            case NIGHT: {
                int[] order = {-1, 1, 0};
                int pos = 0;
                for (int i = 0; i < 3; i++) if (order[i] == s.night) pos = i;
                s.night = order[(pos + d + 3) % 3];
                break;
            }
            case APP: {
                int total = apps.size() + 1;   // +1 pour « Aucune »
                int pos = (appIdx + 1 + d + total) % total;
                appIdx = pos - 1;
                s.pkg = appIdx < 0 ? null : apps.get(appIdx)[0];
                break;
            }
            case TIMER: {
                int pos = 0;
                for (int i = 0; i < TIMERS.length; i++) if (TIMERS[i] == s.timerMin) pos = i;
                s.timerMin = TIMERS[Math.max(0, Math.min(TIMERS.length - 1, pos + d))];
                break;
            }
            case END: {
                int n = Actions.END_NAMES.length;
                s.endAction = (s.endAction + d + n) % n;
                break;
            }
            default:
                break;
        }
        confirmDelete = false;
        render();
    }

    private void askName() {
        final EditText et = new EditText(this);
        et.setText(s.name);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Nom du raccourci")
                .setView(et)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String v = et.getText().toString().trim();
                        if (!v.isEmpty()) s.name = v;
                        render();
                    }
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void save() {
        if (index >= 0) all.set(index, s);
        else all.add(s);
        Shortcut.save(this, all);
        finish();
    }

    private void delete() {
        if (index >= 0) {
            all.remove(index);
            Shortcut.save(this, all);
        }
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        int n = rowCount();
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                row = (row + n - 1) % n;
                confirmDelete = false;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                row = (row + 1) % n;
                confirmDelete = false;
                render();
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                change(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                change(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (e.getRepeatCount() != 0) return true;
                if (row == NAME) askName();
                else if (row == SAVE) save();
                else if (row == DELETE) {
                    if (confirmDelete) delete();
                    else { confirmDelete = true; render(); }
                } else change(1);
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }
}
