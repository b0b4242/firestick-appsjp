package com.jp.hub;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/** Se réveille à la fin de la minuterie d'un raccourci. */
public class HubReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        c.getSharedPreferences(Actions.PREFS, Context.MODE_PRIVATE).edit().remove(Actions.K_TIMER_END).apply();
        final PendingResult result = goAsync();
        long wait = Actions.endAction(c, i.getIntExtra("action", Actions.CLOSE), i.getStringExtra("pkg"));
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { result.finish(); }
        }, wait);
    }
}
