package com.jp.hub;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Tout ce que le Hub sait faire : lancer des apps, piloter Luminosité, programmer une action. */
final class Actions {
    static final String LUMI = "com.jp.luminosite";
    static final String FIRESAVER = "com.jp.firesaver";
    static final String MINUTERIE = "com.jp.minuterie";

    static final String PREFS = "hub";
    static final String K_TIMER_END = "timer_end";

    // Actions possibles à la fin d'une minuterie de raccourci
    static final int CLOSE = 0, OPEN = 1, FIRE = 2, DIM = 3, PAUSE = 4, SOUND = 5;
    static final String[] END_NAMES = {
            "Fermer l'application", "Ouvrir l'application", "Lancer FireSaver",
            "Baisser la luminosité au minimum", "Mettre en pause", "Jouer un son"
    };

    private Actions() { }

    // ---------- apps ----------

    static boolean launch(Context c, String pkg) {
        if (pkg == null) return false;
        PackageManager pm = c.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static String labelOf(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    /** Apps lançables (hors Hub), triées par nom : chaque entrée = {paquet, nom}. */
    static List<String[]> loadApps(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, String> found = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName()) || found.containsKey(pkg)) continue;
                found.put(pkg, String.valueOf(ri.loadLabel(pm)));
            }
        }
        List<String[]> out = new ArrayList<>();
        for (Map.Entry<String, String> e : found.entrySet()) out.add(new String[]{e.getKey(), e.getValue()});
        Collections.sort(out, new Comparator<String[]>() {
            @Override public int compare(String[] a, String[] b) { return a[1].compareToIgnoreCase(b[1]); }
        });
        return out;
    }

    // ---------- Luminosité ----------

    private static Intent lumiIntent(String key, int val) {
        Intent d = new Intent();
        d.setComponent(new ComponentName(LUMI, LUMI + ".ControlReceiver"));
        if (key != null) d.putExtra(key, val);
        return d;
    }

    static void lumi(Context c, String key, int val) {
        c.sendBroadcast(lumiIntent(key, val));
    }

    /** Envoie la commande (ou lit seulement l'état si key est null) et rend la réponse au récepteur. */
    static void lumiRead(Context c, String key, int val, BroadcastReceiver result) {
        c.sendOrderedBroadcast(lumiIntent(key, val), null, result, null, Activity.RESULT_CANCELED, null, null);
    }

    // ---------- action de fin de minuterie ----------

    static PendingIntent pending(Context c, int action, String pkg) {
        Intent i = new Intent(c, HubReceiver.class);
        i.setAction("com.jp.hub.FIRE");
        i.putExtra("action", action);
        i.putExtra("pkg", pkg);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, 7, i, flags);
    }

    static void schedule(Context c, long atMillis, int action, String pkg) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, action, pkg);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, atMillis, pi);
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(K_TIMER_END, atMillis).apply();
    }

    static void cancelTimer(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c, 0, null));
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(K_TIMER_END).apply();
    }

    private static void goHome(Context c) {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(h);
    }

    /** Exécute l'action de fin. Rend le délai (ms) à attendre avant de libérer le récepteur. */
    static long endAction(final Context c, int action, final String pkg) {
        Handler h = new Handler(Looper.getMainLooper());
        try {
            switch (action) {
                case CLOSE:
                    goHome(c);
                    h.postDelayed(new Runnable() {
                        @Override public void run() {
                            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                            if (am != null && pkg != null) am.killBackgroundProcesses(pkg);
                        }
                    }, 1500);
                    return 2500;
                case OPEN:
                    launch(c, pkg);
                    return 0;
                case FIRE:
                    launch(c, FIRESAVER);
                    return 0;
                case DIM:
                    lumi(c, "brightness", 5);
                    return 0;
                case PAUSE:
                    AudioManager a = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                    a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE));
                    a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE));
                    return 0;
                case SOUND:
                    Ringtone r = RingtoneManager.getRingtone(c,
                            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                    if (r != null) r.play();
                    return 3000;
                default:
                    return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }
}
